Updated version of my old VelloImpact Discord bot.
Now using Firebase Realtime Database.




Q : Why make new repo instead of using the old?
A : 'cause why not?

install links (guild) : https://discord.com/oauth2/authorize?client_id=1339815104836931615&permissions=3377701868202048&integration_type=0&scope=bot